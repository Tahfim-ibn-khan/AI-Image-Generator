import React from "react";

const Card = () => {
  return <div>Card</div>;
};

export default Card;
